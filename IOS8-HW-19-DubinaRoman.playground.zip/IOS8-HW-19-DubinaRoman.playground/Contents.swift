import UIKit

struct Users: Decodable {
    var cards: [Card]
}

struct Card: Decodable {
    let name: String
    let manaCost: String
    let type: String
    let setName: String
}

// Переменная в которую я положу JSON в функции getData
var users = Users(cards: [])

func getData(urlRequest: String, users: inout Users) {
        let urlRequest = URL(string: urlRequest)
        guard let url = urlRequest else { return }
        print("Ссылка действительна - ожидание ответа")
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            if error != nil {
                print((error?.localizedDescription)!)
            } else if let response = response as? HTTPURLResponse, response.statusCode == 200 {
                print("Ответ получен - статус кода \(response.statusCode)")
                guard let data = data else { return }
                
                let json = try? JSONDecoder().decode(Users.self, from: data)
                users = cards!
        }
    }.resume()
}

func printResult(for arrayUsers: [Card]) {
    for item in arrayUsers {
        print("Имя карты: \(item.name)")
        print("Тип: \(item.type)")
        print("Мановая стоимость: \(item.manaCost)")
        print("Название сета : \(item.setName)")
    }
}

let url = "https://api.magicthegathering.io/v1/cards?name=Black%20Lotus"
getData(urlRequest: url, users: &users)
printResult(for: <#T##[Card]#>)

